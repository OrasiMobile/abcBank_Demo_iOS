//
//  PickerViewField.h
//  abcBankDemo
//
//  Created by Orasi Software on 5/22/13.
//  Copyright (c) 2013 Orasi Software. All rights reserved.
//


@interface PickerViewField : UIButton
{
    UIView *_inputView;
}
@property (nonatomic, retain) UIView *inputView;
@end
